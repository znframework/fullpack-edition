<?php
//--------------------------------------------------------------------------------------------------
// This file automatically created and updated
//--------------------------------------------------------------------------------------------------

class HTTP extends StaticAccess
{
	const config = ['Services:http', 'Services:route'];

	public static function getClassName()
	{
		return __CLASS__;
	}
}

//--------------------------------------------------------------------------------------------------