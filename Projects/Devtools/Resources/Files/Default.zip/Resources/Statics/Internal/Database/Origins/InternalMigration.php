<?php
//-------------------------------------------------------------------------
// This file automatically created and updated
//-------------------------------------------------------------------------

class Migration extends StaticAccess
{
	const table = __CLASS__;

	public static function getClassName()
	{
		return __CLASS__;
	}
}

//-------------------------------------------------------------------------