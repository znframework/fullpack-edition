<?php
//--------------------------------------------------------------------------------------------------
// This file automatically created and updated
//--------------------------------------------------------------------------------------------------

class DBGrid extends StaticAccess
{
	const config = 'ViewObjects:datagrid', lang = 'ViewObjects:dbgrid';

	public static function getClassName()
	{
		return __CLASS__;
	}
}

//--------------------------------------------------------------------------------------------------