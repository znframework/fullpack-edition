<?php
//--------------------------------------------------------------------------------------------------
// This file automatically created and updated
//--------------------------------------------------------------------------------------------------

class Pagination extends StaticAccess
{
	const config = 'ViewObjects:pagination';

	public static function getClassName()
	{
		return __CLASS__;
	}
}

//--------------------------------------------------------------------------------------------------