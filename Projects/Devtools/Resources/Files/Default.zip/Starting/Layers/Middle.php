<?php
/*
|--------------------------------------------------------------------------
| Middle
|--------------------------------------------------------------------------
|
| Code to be executed in the middle layer of the system is written.
|
| Location: After the beginning of the kernel, before the kernel
|
*/
