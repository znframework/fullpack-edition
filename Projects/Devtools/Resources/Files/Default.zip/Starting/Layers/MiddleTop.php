<?php
/*
|--------------------------------------------------------------------------
| Middle Top
|--------------------------------------------------------------------------
|
| The codes that are required to be run on the middle layer of the system 
| are written.
|
| Location: Before the beginning of the kernel
|
*/
