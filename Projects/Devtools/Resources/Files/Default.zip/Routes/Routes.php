<?php
/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| Your routes.
|
*/

// Example Usage
// Route::method('get', 'post')->change('product/id/:numeric')->uri('product/add');
