<div id="container">
    <div id="content">
        <div id="title">@$pageTitle: @ZN_VERSION: is dedicated to <span id="dedicate">@ZN_DEDICATE:</span></div>
        <div id="sub-title">@$pageSubtitle:</div>
    </div>
</div>