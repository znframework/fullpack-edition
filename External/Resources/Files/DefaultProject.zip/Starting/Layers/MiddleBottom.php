<?php
/*
|--------------------------------------------------------------------------
| Middle Bottom
|--------------------------------------------------------------------------
|
| The codes that are required to run under the middle layer of the system
| are written.
|
| Location: After the kernel is run, before the kernel
|
*/
