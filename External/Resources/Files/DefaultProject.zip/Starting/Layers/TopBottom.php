<?php
/*
|--------------------------------------------------------------------------
| Top Bottom
|--------------------------------------------------------------------------
|
| The codes that are required to run under the top layer of the system 
| are written.
|
| Location: After Autoloader, before Config configuration
|
*/
