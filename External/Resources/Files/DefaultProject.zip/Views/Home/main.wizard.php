<div id="container">
    <div id="content">
        <div>Science is the most genuine guide in life.</div>
    </div>
</div>