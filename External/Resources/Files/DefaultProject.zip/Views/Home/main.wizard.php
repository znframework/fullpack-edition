<div id="container">
    <div id="content">
        <div id="title">ZN <span class="blue-color">6.&#8734;</span> is dedicated to <span class="blue-color">{{ZN_DEDICATE}}</span></div>
        <div id="sub-title" class="grey-color">Science is the most genuine guide in life.</div>
        <div id="the-great-leader"></div>
    </div>
</div>