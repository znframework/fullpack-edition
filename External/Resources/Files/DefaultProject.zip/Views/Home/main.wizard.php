<div id="container">
    <div id="content">
        <div id="title">{{$pageTitle}} <span class="blue-color">{{ZN_VERSION}}</span> is dedicated to <span class="orange-color">{{ZN_DEDICATE}}</span></div>
        <div id="sub-title" class="blue-color">{{$pageSubtitle}}</div>
    </div>
</div>