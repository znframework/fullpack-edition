<div id="container">
    <div id="content">
        <div id="title">ZN <span class="blue-color">{{ZN_VERSION}}</span> is dedicated to <span class="blue-color">{{ZN_DEDICATE}}</span></div>
        <div id="sup-title-2" class="grey-color">
            n
        </div>
        <div id="sub-title" class="grey-color">
            Arf(q) = <span class="sum">&sum;</span> q(a<sub>i</sub>)q(b<sub>i</sub>) &isin; &Zeta;<sub>2</sub>
        </div>
        <div id="sub-title-2" class="grey-color">
            i=1
        </div>
        <div id="sub-title-3" class="grey-color">
            a<sub>i</sub>, b<sub>i</sub> i = 1, 2, 3, ..., n
        </div>
    </div>
</div>