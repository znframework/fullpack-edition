<div id="container">
    <div id="content">
        <div id="sub-title" class="title-size"><span class="blue-color">404</span></div>
        <div id="title">The page you searched for was not found!</div>
    </div>
</div>