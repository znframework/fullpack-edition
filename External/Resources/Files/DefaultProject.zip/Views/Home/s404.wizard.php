<div id="container">
    <div id="content">
        <div id="title" class="title-size"><span class="blue-color">{{$pageTitle}}</span></div>
        <div id="sub-title">{{$pageSubtitle}}</div>
    </div>
</div>