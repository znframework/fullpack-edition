<div id="container">
    <div id="content">
        <div>404! File Not Found</div>
    </div>
</div>