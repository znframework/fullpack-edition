<?php namespace Project\Commands;

use ZN\Command;

class Example extends Command
{
    public function run()
    {
        # Your codes here.
    }
}