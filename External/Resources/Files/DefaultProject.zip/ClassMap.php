<?php
#----------------------------------------------------------------------
# This file automatically created and updated
#----------------------------------------------------------------------
$classMap['classes']['project\controllers\home'] = 'Projects/Frontend/Controllers/Home.php';
$classMap['classes']['project\controllers\initialize'] = 'Projects/Frontend/Controllers/Initialize.php';
$classMap['namespaces']['project\controllers\home'] = 'home';
$classMap['namespaces']['project\controllers\initialize'] = 'initialize';
